var class_obstacle =
[
    [ "Obstacle", "class_obstacle.html#a36a36b010573296be26d0aeb33c292e3", null ],
    [ "ToString", "class_obstacle.html#a4d711674e6d21779907acd4c170542e3", null ],
    [ "tipo", "class_obstacle.html#aa014e3eeda1d1dd10c5304fa846da284", null ],
    [ "X", "class_obstacle.html#a9c2af7a4e2f884584b6964afeca63197", null ],
    [ "Y", "class_obstacle.html#a828535ddc133dcc0546ac94aa33bf398", null ]
];