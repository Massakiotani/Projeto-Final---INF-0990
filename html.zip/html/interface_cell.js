var interface_cell =
[
    [ "X", "interface_cell.html#a621087323dae8267784e6783d5aaec35", null ],
    [ "Y", "interface_cell.html#a9ca1aa9e1edf7c15dd5f193033dd55cb", null ]
];