var searchData=
[
  ['empty_0',['Empty',['../class_empty.html',1,'']]]
];
