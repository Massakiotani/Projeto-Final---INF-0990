var searchData=
[
  ['tipo_0',['tipo',['../class_obstacle.html#aa014e3eeda1d1dd10c5304fa846da284',1,'Obstacle']]],
  ['type_1',['type',['../class_jewel.html#a87474421d378534ef6ebcb73f658033a',1,'Jewel']]]
];
