var searchData=
[
  ['sacola_0',['sacola',['../class_robot.html#a2dc27f7a753627ac388512846009f98b',1,'Robot']]],
  ['subscribetokeystrokes_1',['SubscribeToKeystrokes',['../class_robot.html#a3094cc3992f016dc64cd43d6624cc6b1',1,'Robot']]]
];
