var class_empty =
[
    [ "Empty", "class_empty.html#a1387e0a7c292390ca8dedfc35ca336a3", null ],
    [ "ToString", "class_empty.html#a2b70a6e29556d19085d7039ccc0d81ec", null ],
    [ "X", "class_empty.html#ac70e935f26c3b0fe7045fddef13419b3", null ],
    [ "Y", "class_empty.html#a66608c8b7cdcf78035cd13e6a0266473", null ]
];