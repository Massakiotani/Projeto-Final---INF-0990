var class_jewel =
[
    [ "Jewel", "class_jewel.html#abcc9aeba526c039e9538b858b003f06b", null ],
    [ "ToString", "class_jewel.html#a059005d8c38fa9739dc761b05294335a", null ],
    [ "type", "class_jewel.html#a87474421d378534ef6ebcb73f658033a", null ],
    [ "X", "class_jewel.html#a92728797d6e99974b1638bcc0cf8864d", null ],
    [ "Y", "class_jewel.html#a428566e8ef113de5e32111e5b9478ac8", null ]
];