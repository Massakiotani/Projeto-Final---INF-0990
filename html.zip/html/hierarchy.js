var hierarchy =
[
    [ "Cell", "interface_cell.html", [
      [ "Empty", "class_empty.html", null ],
      [ "Jewel", "class_jewel.html", null ],
      [ "Obstacle", "class_obstacle.html", null ],
      [ "Robot", "class_robot.html", null ]
    ] ],
    [ "JewelCollector", "class_jewel_collector.html", null ],
    [ "Map", "class_map.html", null ]
];